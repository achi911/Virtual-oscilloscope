clear
clc
%Generating a square wave
n=-127:128;
yn=100*square(n,50);
%Draw a square wave waveform and verify the waveform
plot(n,yn);
%creat a new .coe file named Square_Wave_Rom.coe
fid = fopen ('./Square_Wave_Rom.coe','wt');
%enter the .coe file start file header into the file
%memor_initialization_radix = 10
%memory_initialization_vector =
fprintf(fid , 'memory_initialization_radix = 10;\nmemory_initialization_vector=');


%output 256 waveform sample pionts to a.coe file
for i = 1:256
    
    %Wrap processing, no need
    if mod(i-1,8) == 0
        
        fprintf(fid,'\n');
        
    end
    %considering the 8-bit ADC, the value cannot exceed 255, and cannot be lower than zero
    if yn(i)<0
        fprintf(fid,'%4d',0);
    else
        fprintf(fid,'%4d',yn(i));
    end
end
